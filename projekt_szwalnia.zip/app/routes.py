from flask import render_template, request, redirect, url_for, flash, send_from_directory, current_app, make_response, jsonify, send_file, after_this_request
from app import app, db
from app.models import Order, Client, Product, OrderItem, Attachment, OrderTemplate, Fabric
from app.forms import OrderForm, OrderTemplateForm
from werkzeug.utils import secure_filename
import os
from datetime import datetime, date, timedelta
import pdfkit
from sqlalchemy import extract
from app.doc_generator import save_order_as_word


# Jeśli wkhtmltopdf nie jest w PATH, ustaw konfigurację, np.:
config = pdfkit.configuration(wkhtmltopdf=r'C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe')


# Dozwolone rozszerzenia dla załączników
ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg', 'doc', 'docx'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return redirect(url_for('orders_list'))

from flask import send_file

@app.route('/orders/new', methods=['GET', 'POST'])
def new_order():
    form = OrderForm()
    template_id = request.args.get('template_id', type=int)
    if request.method == 'GET' and template_id:
        order_template = OrderTemplate.query.get(template_id)
        if order_template:
            form.client_name.data = order_template.client_name.upper()
            form.description.data = order_template.description.upper()

    if form.validate_on_submit():
        client_name = form.client_name.data.strip().upper()
        client = Client.query.filter_by(name=client_name).first()
        if not client:
            client = Client(name=client_name)
            db.session.add(client)
            db.session.commit()

        # obsługa tkaniny
        fabric_name = form.fabric_name.data.strip().upper() if form.fabric_name.data else None
        fabric = None
        if fabric_name:
            fabric = Fabric.query.filter_by(name=fabric_name).first()
            if not fabric:
                fabric = Fabric(name=fabric_name)
                db.session.add(fabric)
                db.session.commit()

        order = Order(
            client_id=client.id,
            description=form.description.data.strip().upper(),
            fabric_id=fabric.id if fabric else None,
            login_info=form.login_info.data.strip().upper() if form.login_info.data else None,
            deadline=form.deadline.data,
            status='NOWE',
            zlecajacy=form.zlecajacy.data.upper()
        )
        db.session.add(order)
        db.session.commit()

        for prod_data in form.products.data:
            product_name = prod_data['product_name'].strip().upper()
            product = Product.query.filter_by(name=product_name).first()
            if not product:
                product = Product(name=product_name)
                db.session.add(product)
                db.session.commit()
            for variant in prod_data['variants']:
                size = variant['size'].strip().upper()
                try:
                    quantity = int(variant['quantity'])
                except:
                    quantity = 0
                if quantity <= 0:
                    continue
                order_item = OrderItem(
                    order_id=order.id,
                    product_id=product.id,
                    size=size,
                    quantity=quantity
                )
                db.session.add(order_item)
        db.session.commit()

        today = date.today()
        order.order_code = f"{today.year}/{today.month:02d}/{today.day:02d}-{order.id}"
        db.session.commit()

        # Automatyczne zapisanie dokumentu Word na dysk i zwrócenie ścieżki
        filepath = save_order_as_word(order)

        # Obsługa załączników
        if 'attachments' in request.files:
            files = request.files.getlist('attachments')
            for file in files:
                if file and allowed_file(file.filename):
                    filename = secure_filename(file.filename)
                    timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
                    filename = f"{timestamp}_{order.id}_{filename}"
                    file.save(os.path.join(current_app.config['UPLOAD_FOLDER'], filename))
                    attachment = Attachment(order_id=order.id, filename=filename)
                    db.session.add(attachment)
            db.session.commit()

        # Zapis szablonu, jeśli zaznaczono
        if form.save_template.data:
            template_name = form.template_name.data.strip().upper()
            if template_name == "":
                flash('Podaj nazwę szablonu, jeśli chcesz zapisać szablon.', 'danger')
            else:
                if OrderTemplate.query.filter_by(template_name=template_name).first():
                    flash('Szablon o tej nazwie już istnieje. Wybierz inną nazwę.', 'danger')
                else:
                    order_template = OrderTemplate(
                        template_name=template_name,
                        client_name=client_name,
                        description=form.description.data.strip().upper()
                    )
                    db.session.add(order_template)
                    db.session.commit()
                    flash('Szablon został zapisany.', 'info')

        flash('Zlecenie zostało dodane.', 'success')

        # Po wygenerowaniu pliku zwracamy go do użytkownika
        return send_file(
            filepath,
            as_attachment=True,
            download_name=os.path.basename(filepath),
            mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        )

    existing_products = Product.query.all()
    existing_clients = Client.query.all()
    existing_fabrics = Fabric.query.all()  # dodane

    return render_template('order_form.html',
                           form=form,
                           products=existing_products,
                           clients=existing_clients,
                           fabrics=existing_fabrics)


# --- Nowe widoki dla szablonów ---

@app.route('/order_templates')
def order_templates():
    templates = OrderTemplate.query.order_by(OrderTemplate.created_at.desc()).all()
    return render_template('order_templates_list.html', templates=templates)

@app.route('/order_templates/new', methods=['GET', 'POST'])
def new_template():
    from app.forms import OrderTemplateForm  # import wewnątrz, by uniknąć cyklicznych importów
    form = OrderTemplateForm()
    clients = Client.query.all()
    if form.validate_on_submit():
        template_name = form.template_name.data.strip().upper()
        client_name = form.client_name.data.strip().upper()
        description = form.description.data.strip().upper()
        if OrderTemplate.query.filter_by(template_name=template_name).first():
            flash('Szablon o tej nazwie już istnieje. Wybierz inną nazwę.', 'danger')
        else:
            template = OrderTemplate(
                template_name=template_name,
                client_name=client_name,
                description=description
            )
            db.session.add(template)
            db.session.commit()
            flash('Szablon został utworzony.', 'success')
            return redirect(url_for('order_templates'))
    return render_template('order_template_form.html', form=form, clients=clients)

@app.route('/order_templates/edit/<int:template_id>', methods=['GET', 'POST'])
def edit_template(template_id):
    from app.forms import OrderTemplateForm
    template = OrderTemplate.query.get_or_404(template_id)
    form = OrderTemplateForm(obj=template)
    clients = Client.query.all()
    if form.validate_on_submit():
        template.template_name = form.template_name.data.strip().upper()
        template.client_name = form.client_name.data.strip().upper()
        template.description = form.description.data.strip().upper()
        db.session.commit()
        flash('Szablon został zaktualizowany.', 'success')
        return redirect(url_for('order_templates'))
    return render_template('order_template_form.html', form=form, clients=clients)

@app.route('/orders')
def orders_list():
    client_filter = request.args.get('client', '').strip().upper()
    status_filter = request.args.get('status', '').strip().upper()
    year_filter = request.args.get('year', '')
    month_filter = request.args.get('month', '')
    orders_query = Order.query.join(Client)
    
    if client_filter:
        orders_query = orders_query.filter(Client.name == client_filter)
    if status_filter:
        orders_query = orders_query.filter(Order.status == status_filter)
    if year_filter:
        orders_query = orders_query.filter(extract('year', Order.created_at) == int(year_filter))
    if month_filter:
        orders_query = orders_query.filter(extract('month', Order.created_at) == int(month_filter))
    
    orders = orders_query.order_by(Order.created_at.desc()).all()
    
    # Generowanie listy lat, które występują w zamówieniach
    years_query = db.session.query(extract('year', Order.created_at)).distinct().all()
    years = sorted({int(y[0]) for y in years_query})
    
    clients = Client.query.order_by(Client.name).all()
    return render_template('orders_list.html', orders=orders, clients=clients, years=years)

@app.route('/orders/<int:order_id>')
def order_detail(order_id):
    order = Order.query.get_or_404(order_id)
    return render_template('order_detail.html', order=order)



@app.route('/orders/<int:order_id>/status', methods=['POST'])
def update_order_status(order_id):
    order = Order.query.get_or_404(order_id)
    new_status = request.form.get('status')
    if new_status:
        order.status = new_status
        db.session.commit()
        flash('Status zlecenia został zaktualizowany.', 'success')
        # Jeśli żądanie jest AJAX, zwróć JSON:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify(success=True, order_id=order.id, status=order.status)
    # W przypadku zwykłego żądania wykonaj przekierowanie
    return redirect(url_for('order_detail', order_id=order.id))


@app.route('/orders/<int:order_id>/pdf')
def order_pdf(order_id):
    order = Order.query.get_or_404(order_id)
    rendered = render_template('order_pdf.html', order=order)
    # Wygeneruj PDF na podstawie renderowanego HTML
    pdf = pdfkit.from_string(rendered, False, configuration=config)
    response = make_response(pdf)
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = f'inline; filename=zlecenie_{order.id}.pdf'
    return response

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(current_app.config['UPLOAD_FOLDER'], filename)



@app.route('/products')
def products_list():
    products = Product.query.order_by(Product.name).all()
    return render_template('products_list.html', products=products)

@app.route('/orders/<int:order_id>/delete', methods=['POST'])
def delete_order(order_id):
    order = Order.query.get_or_404(order_id)
    db.session.delete(order)
    db.session.commit()
    flash('Zlecenie zostało usunięte.', 'success')
    return redirect(url_for('orders_list'))

@app.route('/orders/<int:order_id>/print')
def order_print(order_id):
    order = Order.query.get_or_404(order_id)
    return render_template('order_print.html', order=order)

@app.route('/orders/<int:order_id>/labels')
def order_labels(order_id):
    order = Order.query.get_or_404(order_id)
    template_choice = request.args.get('template', 'cotton')  # domyślnie cotton
    # W zależności od template_choice, generujemy inny skład / layout
    # Dla uproszczenia, wstrzykniemy w label_template.html pewne if-y
    rendered_html = render_template('label_template.html', order=order, template_choice=template_choice)

    options = {
        'page-width': '40mm',
        'page-height': '300mm',
        'margin-top': '0mm',
        'margin-bottom': '0mm',
        'margin-left': '0mm',
        'margin-right': '0mm',
        'disable-smart-shrinking': ''
    }
    pdf = pdfkit.from_string(rendered_html, False, configuration=config, options=options)

    response = make_response(pdf)
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = 'inline; filename=labels.pdf'
    return response

@app.route('/orders/<int:order_id>/choose_label')
def choose_label(order_id):
    order = Order.query.get_or_404(order_id)
    # Opcjonalnie: przekazanie ścieżek do obrazków dla szablonów
    order_template_images = {
        'cotton': '/static/images/label_cotton.png',
        'polyester': '/static/images/label_polyester.png',
        'mixed': '/static/images/label_mixed.png'
    }
    return render_template('choose_label.html', order=order, order_template_images=order_template_images)

@app.route('/orders/<int:order_id>/download_doc')
def download_doc(order_id):
    order = Order.query.get_or_404(order_id)
    # Generujemy dokument Word (zapis w folderze na serwerze, ale plik zostanie wysłany do klienta)
    filepath = save_order_as_word(order, folder_path='order_docs')
    # Używamy send_file, aby wysłać plik jako attachment
    return send_file(
        filepath,
        as_attachment=True,
        download_name=os.path.basename(filepath),
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )

@app.route('/api/fabrics')
def api_fabrics():
    fabrics = Fabric.query.order_by(Fabric.name).all()
    return jsonify([f.name for f in fabrics])

@app.route('/orders/<int:order_id>/material_usage', methods=['GET', 'POST'])
def edit_material_usage(order_id):
    order = Order.query.get_or_404(order_id)

    if request.method == 'POST':
        usage = request.form.get('material_usage', '').strip()
        order.material_usage = usage
        db.session.commit()
        flash('Zużycie materiałów zostało zaktualizowane.', 'success')
        return redirect(url_for('orders_list'))

    return render_template('edit_material_usage.html', order=order)
