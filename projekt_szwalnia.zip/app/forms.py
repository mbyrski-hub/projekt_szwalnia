from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, DateField, SelectField, FieldList, FormField, SubmitField, BooleanField, IntegerField
from wtforms.validators import DataRequired
from wtforms import Form

# Formularz dla pojedynczego wariantu produktu (rozmiar + ilość)
class ProductVariantForm(Form):
    size = StringField('Rozmiar', validators=[DataRequired()])
    quantity = IntegerField('Ilość', validators=[DataRequired()])

# Formularz dla jednego produktu w zleceniu – nazwa produktu i lista wariantów
class OrderProductForm(Form):
    product_name = StringField('Nazwa produktu', validators=[DataRequired()])
    variants = FieldList(FormField(ProductVariantForm), min_entries=1, max_entries=10)

# Główny formularz zlecenia – lista produktów (każdy z wariantami)
class OrderForm(FlaskForm):
    client_name = StringField('Nazwa klienta', validators=[DataRequired()])
    description = TextAreaField('Opis zlecenia', validators=[DataRequired()])
    fabric_name = StringField('Tkanina (opcjonalnie)')
    login_info = TextAreaField('Logowanie (opcjonalne)')
    deadline = DateField('Termin realizacji (RRRR-MM-DD)', format='%Y-%m-%d', validators=[DataRequired()])
    products = FieldList(FormField(OrderProductForm), min_entries=1, max_entries=10)
    zlecajacy = SelectField('Zlecający', choices=[
        ('SZEF', 'SZEF'), ('JOLA', 'JOLA'), ('ANIA', 'ANIA'),
        ('WOJTEK', 'WOJTEK'), ('MATEUSZ', 'MATEUSZ'), ('KINGA', 'KINGA'), ('FIRMA', 'FIRMA')
    ], validators=[DataRequired()])
    save_template = BooleanField('Zapisz jako szablon')
    template_name = StringField('Nazwa szablonu (jeśli zapisujesz)')
    submit = SubmitField('Dodaj zlecenie')


# Formularz do dodawania/edycji szablonu
class OrderTemplateForm(FlaskForm):
    template_name = StringField('Nazwa szablonu', validators=[DataRequired()])
    client_name = StringField('Nazwa klienta', validators=[DataRequired()])
    description = TextAreaField('Opis zlecenia', validators=[DataRequired()])
    submit = SubmitField('Zapisz szablon')
