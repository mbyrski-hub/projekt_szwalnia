from app import db
from datetime import datetime

class Client(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    orders = db.relationship('Order', backref='client', lazy=True)

    def __repr__(self):
        return f'<Client {self.name}>'
    
class Fabric(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)

    def __repr__(self):
        return f'<Fabric {self.name}>'
    

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_code = db.Column(db.String(50), nullable=True)
    client_id = db.Column(db.Integer, db.ForeignKey('client.id', name='fk_order_client_id'), nullable=False)
    description = db.Column(db.Text, nullable=False)
    # Nowe pole – opcjonalne
    login_info = db.Column(db.Text, nullable=True)
    deadline = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(50), nullable=False, default='NOWE')
    zlecajacy = db.Column(db.String(50), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    order_items = db.relationship('OrderItem', backref='order', lazy=True, cascade="all, delete-orphan")
    attachments = db.relationship('Attachment', backref='order', lazy=True, cascade="all, delete-orphan")
    fabric_id = db.Column(db.Integer, db.ForeignKey('fabric.id', name='fk_fabric_id'), nullable=True)
    fabric = db.relationship('Fabric', backref='orders')
    material_usage = db.Column(db.Text, nullable=True)  # nowe pole – zużycie materiałów
    
    def __repr__(self):
        return f'<Order {self.id} - Client: {self.client.name} - Code: {self.order_code}>'


class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)

    def __repr__(self):
        return f'<Product {self.name}>'

class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id', name='fk_orderitem_order_id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id', name='fk_orderitem_product_id'), nullable=False)
    size = db.Column(db.String(50), nullable=False)  # wpisywany ręcznie
    quantity = db.Column(db.Integer, nullable=False)  # nowe pole ilości
    product = db.relationship('Product', backref='order_items')

    def __repr__(self):
        return f'<OrderItem Order:{self.order_id} Product:{self.product.name} Size:{self.size} Qty:{self.quantity}>'

class Attachment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id', name='fk_attachment_order_id'), nullable=False)
    filename = db.Column(db.String(200), nullable=False)
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<Attachment {self.filename} for Order {self.order_id}>'

class OrderTemplate(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    template_name = db.Column(db.String(100), nullable=False, unique=True)
    client_name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<OrderTemplate {self.template_name}>'
