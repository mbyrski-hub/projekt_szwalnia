import os
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from datetime import datetime

def save_order_as_word(order, folder_path='order_docs'):
    # Utwórz nowy dokument
    doc = Document()
    
    # ---- Nagłówek ----
    header = doc.add_paragraph()
    header.alignment = WD_ALIGN_PARAGRAPH.CENTER
    header_run = header.add_run("Zlecenie Produkcyjne")
    header_run.font.size = Pt(24)
    header_run.font.color.rgb = RGBColor(0x00, 0x56, 0xB3)

    order_code_par = doc.add_paragraph()
    order_code_par.alignment = WD_ALIGN_PARAGRAPH.CENTER
    order_code_run = order_code_par.add_run("Nr zlecenia: " + order.order_code)
    order_code_run.font.size = Pt(16)

    doc.add_paragraph()

    # ---- Szczegóły zlecenia ----
    details = doc.add_paragraph()
    details_run = details.add_run("Klient: " + order.client.name + "\n")
    details_run.font.size = Pt(16)
    details_run = details.add_run("Opis: " + order.description + "\n")
    # Dodanie tkaniny (opcjonalnie)
    fabric_text = order.fabric.name if order.fabric else "brak"
    details_run = details.add_run("Tkanina: " + fabric_text + "\n")
    details_run.font.size = Pt(16)
    # Logowanie (znakowanie)
    login_text = order.login_info if order.login_info else "brak"
    details_run = details.add_run("Logowanie: " + login_text + "\n")
    details_run.font.size = Pt(16)
    details_run.font.size = Pt(16)
    details_run = details.add_run("Termin: " + order.deadline.strftime('%Y-%m-%d') + "\n")
    details_run.font.size = Pt(16)
    details_run = details.add_run("Status: " + order.status + "\n")
    details_run.font.size = Pt(16)
    details_run = details.add_run("Zlecający: " + order.zlecajacy + "\n")
    details_run.font.size = Pt(16)

    doc.add_paragraph()

    # ---- Tabela produktów ----
    doc.add_heading("Produkty", level=1)
    table = doc.add_table(rows=1, cols=3)
    hdr_cells = table.rows[0].cells
    hdr_cells[0].text = 'Produkt'
    hdr_cells[1].text = 'Rozmiar'
    hdr_cells[2].text = 'Ilość'

    for item in order.order_items:
        row_cells = table.add_row().cells
        row_cells[0].text = item.product.name
        row_cells[1].text = item.size
        row_cells[2].text = str(item.quantity)

    doc.add_paragraph()

    # ---- Stopka ----
    footer = doc.add_paragraph()
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    footer_run = footer.add_run("Data utworzenia: " + order.created_at.strftime('%Y-%m-%d %H:%M'))
    footer_run.font.size = Pt(10)
    footer_run.font.color.rgb = RGBColor(0x77, 0x77, 0x77)

    base_dir = os.path.abspath(os.path.dirname(__file__))
    docs_dir = os.path.join(base_dir, folder_path)
    if not os.path.exists(docs_dir):
        os.makedirs(docs_dir)

    # --- TUTAJ jest poprawka ---
    filename = f"{order.order_code.replace('/', '_')}_{order.id}_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}.docx"
    filepath = os.path.join(docs_dir, filename)

    doc.save(filepath)
    print("Dokument Word zapisany:", filepath)
    return filepath
